public interface Sort{
	public void sort();
	public void setValues(int[] values);
	public void setViewer(Viewer v);
}